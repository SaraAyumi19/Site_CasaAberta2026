document.addEventListener("DOMContentLoaded", function () {

    /* =========================
       PEGAR RESULTADO DO QUIZ
    ========================= */

    const pontuacao =
        Number(
            localStorage.getItem("pontuacao")
        );

    const totalPerguntas =
        Number(
            localStorage.getItem("totalPerguntas")
        );


    /* =========================
       ELEMENTOS
    ========================= */

    const pontosElemento =
        document.getElementById("pontos");

    const totalElemento =
        document.getElementById("total");

    const mensagemElemento =
        document.getElementById("mensagem");

    const botaoContinuar =
        document.getElementById("continuar");


    /* =========================
       VERIFICAR ELEMENTOS
    ========================= */

    if (
        !pontosElemento ||
        !totalElemento ||
        !mensagemElemento ||
        !botaoContinuar
    ) {

        console.error(
            "Erro: elementos da página de resultado não foram encontrados."
        );

        return;
    }


    /* =========================
       VALORES
    ========================= */

    const pontuacaoFinal =
        Number.isFinite(pontuacao)
            ? pontuacao
            : 0;

    const totalFinal =
        Number.isFinite(totalPerguntas) &&
        totalPerguntas > 0
            ? totalPerguntas
            : 10;


    /* =========================
       MOSTRAR RESULTADO
    ========================= */

    pontosElemento.textContent =
        pontuacaoFinal;

    totalElemento.textContent =
        totalFinal;


    /* =========================
       CALCULAR PORCENTAGEM
    ========================= */

    const porcentagem =
        (pontuacaoFinal / totalFinal) * 100;


    /* =========================
       MENSAGEM
    ========================= */

    if (porcentagem === 100) {

        mensagemElemento.textContent =
            "Perfeito! Você acertou tudo! ✨";

    }

    else if (porcentagem >= 70) {

        mensagemElemento.textContent =
            "Muito bem! Você foi muito bem! ♡";

    }

    else if (porcentagem >= 50) {

        mensagemElemento.textContent =
            "Bom trabalho! Continue praticando!";

    }

    else {

        mensagemElemento.textContent =
            "Não desanime! Você pode tentar novamente!";

    }


    /* =========================
       ENTRADA
    ========================= */

    requestAnimationFrame(function () {

        document.body.classList.add("entrou");

    });


    /* =========================
       IR PARA FINALIZAÇÃO
    ========================= */

    botaoContinuar.addEventListener(
        "click",
        function () {

            document.body.classList.remove(
                "entrou"
            );

            document.body.classList.add(
                "saindo"
            );


            setTimeout(function () {

                window.location.href =
                    "../pgs/Finalizacao.html";

            }, 900);

        }
    );

});
