document.addEventListener("DOMContentLoaded", function () {

    /* =========================
       ENTRADA
    ========================= */

    requestAnimationFrame(function () {

        document.body.classList.add("entrou");

    });


    /* =========================
       BOTÃO INÍCIO
    ========================= */

    const botaoInicio =
        document.getElementById("inicio");


    if (!botaoInicio) {
        return;
    }


    botaoInicio.addEventListener(
        "click",
        function () {

            // Limpa o resultado anterior
            localStorage.removeItem("pontuacao");
            localStorage.removeItem("totalPerguntas");


            // Animação de saída
            document.body.classList.remove(
                "entrou"
            );

            document.body.classList.add(
                "saindo"
            );


            // Voltar para a primeira página
            setTimeout(function () {

                window.location.href =
                    "../pgs/Inicio.html";

            }, 900);

        }
    );

});
