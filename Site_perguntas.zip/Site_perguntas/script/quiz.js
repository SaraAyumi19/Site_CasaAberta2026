document.addEventListener("DOMContentLoaded", function () {

    /* =========================
       PERGUNTAS
    ========================= */

    const perguntas = [

        {
            pergunta: "A Terra é o terceiro planeta do Sistema Solar.",
            resposta: true
        },

        {
            pergunta: "O Sol é um planeta.",
            resposta: false
        },

        {
            pergunta: "A água ferve a 100°C ao nível do mar.",
            resposta: true
        },

        {
            pergunta: "O Brasil fica na Europa.",
            resposta: false
        },

        {
            pergunta: "A Lua é um satélite natural da Terra.",
            resposta: true
        },

        {
            pergunta: "2 + 2 é igual a 5.",
            resposta: false
        },

        {
            pergunta: "O oceano Atlântico é um oceano da Terra.",
            resposta: true
        },

        {
            pergunta: "A baleia é um peixe.",
            resposta: false
        },

        {
            pergunta: "O ser humano possui dois pulmões.",
            resposta: true
        },

        {
            pergunta: "Marte é conhecido como o planeta vermelho.",
            resposta: true
        }

    ];


    /* =========================
       ELEMENTOS
    ========================= */

    const perguntaElemento =
        document.getElementById("pergunta");

    const numeroElemento =
        document.getElementById("numero");

    const botaoVerdadeiro =
        document.getElementById("verdadeiro");

    const botaoFalso =
        document.getElementById("falso");


    /* =========================
       VERIFICAR ELEMENTOS
    ========================= */

    if (
        !perguntaElemento ||
        !numeroElemento ||
        !botaoVerdadeiro ||
        !botaoFalso
    ) {

        console.error(
            "Erro: elementos do Quiz não foram encontrados."
        );

        return;
    }


    /* =========================
       VARIÁVEIS
    ========================= */

    let perguntaAtual = 0;
    let pontuacao = 0;
    let respondendo = false;


    /* =========================
       ENTRADA DA PÁGINA
    ========================= */

    requestAnimationFrame(function () {
        document.body.classList.add("entrou");
    });


    /* =========================
       MOSTRAR PERGUNTA
    ========================= */

    function mostrarPergunta() {

        const pergunta =
            perguntas[perguntaAtual];


        if (!pergunta) {
            finalizarQuiz();
            return;
        }


        perguntaElemento.textContent =
            pergunta.pergunta;

        numeroElemento.textContent =
            `${perguntaAtual + 1} / ${perguntas.length}`;

    }


    /* =========================
       RESPONDER
    ========================= */

    function responder(respostaUsuario) {

        // Evita dois cliques rápidos
        if (respondendo) {
            return;
        }

        respondendo = true;


        const pergunta =
            perguntas[perguntaAtual];


        // Verifica resposta
        if (
            respostaUsuario ===
            pergunta.resposta
        ) {

            pontuacao++;

        }


        // Próxima pergunta
        perguntaAtual++;


        // Pequeno atraso entre perguntas
        setTimeout(function () {

            respondendo = false;


            if (
                perguntaAtual <
                perguntas.length
            ) {

                mostrarPergunta();

            } else {

                finalizarQuiz();

            }

        }, 200);

    }


    /* =========================
       FINALIZAR QUIZ
    ========================= */

    function finalizarQuiz() {

        // Salva resultado
        localStorage.setItem(
            "pontuacao",
            pontuacao
        );

        localStorage.setItem(
            "totalPerguntas",
            perguntas.length
        );


        // Animação de saída
        document.body.classList.remove("entrou");
        document.body.classList.add("saindo");


        // Vai para resultado
        setTimeout(function () {

            window.location.href =
                "../pgs/Resultado.html";

        }, 900);

    }


    /* =========================
       BOTÃO VERDADEIRO
    ========================= */

    botaoVerdadeiro.addEventListener(
        "click",
        function () {

            responder(true);

        }
    );


    /* =========================
       BOTÃO FALSO
    ========================= */

    botaoFalso.addEventListener(
        "click",
        function () {

            responder(false);

        }
    );


    /* =========================
       INICIAR
    ========================= */

    mostrarPergunta();

});
