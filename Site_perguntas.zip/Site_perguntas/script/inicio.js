document.addEventListener("DOMContentLoaded", () => {

    // Entrada da página
    requestAnimationFrame(() => {
        document.body.classList.add("entrou");
    });


    // Botão Começar
    const link = document.querySelector(".button");

    if (link) {

        link.addEventListener("click", function (event) {

            event.preventDefault();

            document.body.classList.add("saindo");

            setTimeout(() => {
                window.location.href = link.href;
            }, 900);

        });

    }

});
