document.addEventListener("DOMContentLoaded", function () {

    // =========================
    // ENTRADA DA PÁGINA
    // =========================

    requestAnimationFrame(function () {
        document.body.classList.add("entrou");
    });


    // =========================
    // BOTÃO CONTINUAR
    // =========================

    const botao = document.getElementById("continuarQuiz");

    if (!botao) {
        console.error("Botão continuar não encontrado.");
        return;
    }


    botao.addEventListener("click", function (event) {

        event.preventDefault();

        const destino = botao.getAttribute("href");


        // Animação de saída
        document.body.classList.remove("entrou");
        document.body.classList.add("saindo");


        // Aguarda a animação
        setTimeout(function () {

            window.location.href = destino;

        }, 900);

    });

});
